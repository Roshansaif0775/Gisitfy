package com.gistify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GistifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(GistifyApplication.class, args);
	}

}
