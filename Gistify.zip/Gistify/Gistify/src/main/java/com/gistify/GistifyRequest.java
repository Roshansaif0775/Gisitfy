package com.gistify;

import lombok.Data;

@Data
public class GistifyRequest {
    private String content ;
    private String operation ;
}
